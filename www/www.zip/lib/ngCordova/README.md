ngCordova: Cordova with Angulary Goodness
==========

<img src="http://ionicframework.com/img/ngcordova-context-logo.png" alt="ngCordova Logo" width="210px" height="210px" />

[http://ngCordova.com](http://ngcordova.com/)

AngularJS Cordova wrappers for common Cordova plugins.

Created by the [Ionic Framework](http://ionicframework.com/) team.
