/**
 * Created with JetBrains WebStorm.
 * User: zeeshanhanif
 * Date: 7/26/14
 * Time: 10:50 AM
 * To change this template use File | Settings | File Templates.
 */

angular.module('starter.controllers')
    .controller('AccountCtrl', function($scope, $http, $location) {
    console.log('account');

    });