
angular.module('starter.controllers').controller('WorkOrderCtrl', function($scope, $http,
       $cordovaGeolocation, $cordovaCamera, $stateParams,  $location, Workorders, Authentication, $ionicActionSheet) {

    $scope.authentication = Authentication;
    $scope.user = $scope.authentication.user;

    $scope.workorders = [];
    $scope.workorder = {};
    $scope.latitude = '';
    $scope.longitude = '';
    $scope.lastTime = '';
    $scope.lastStatus = '';

    console.log('work order');
    if (!$scope.user)
        $location.path('tab/signin');

    $scope.find = function() {
        Workorders.getByContact($scope.user._id,function(data) {
            $scope.workorders = data;
        });
    };

    $scope.showOptions = function() {
        // Show the action sheet
        console.log('yo');
        var hideSheet = $ionicActionSheet.show({
            buttons: [
                { text: 'Travel Time', code:'travel' },
                { text: 'Working', code:'working' },
                { text: 'Getting Parts', code:'parts' },
                { text: 'Pause Working', code:'paused' },
                { text: 'Work Order Finished', code:'completed' }
            ],
            titleText: 'Update your status',
            cancelText: 'Cancel',
            cancel: function() {
                // add cancel code..
            },
            buttonClicked: function(index, buttons) {
                $scope.workorderLog(buttons.code);
                return true;
            }
        });
    };

    $cordovaGeolocation.getCurrentPosition().then(function(position) {
            // Position here: position.coords.latitude, position.coords.longitude
            $scope.latitude = position.coords.latitude;
            $scope.longitude = position.coords.longitude;

        }, function(err) {
            // error
        }
    );


    $scope.findOne = function() {
        Workorders.get($stateParams.workorderId, function(data) {
            $scope.workorder = data;
        });

    };

    $scope.workorderLog = function(entryType) {

        console.log(Authentication);
        var workorderLog = {
            vendorUser:Authentication.user._id,
            type:entryType,
            latitude: $scope.latitude,
            longitude: $scope.longitude,
            gpsLocation:$scope.latitude + ',' + $scope.longitude,
            start:new Date()
        };
        //console.log($scope.workorder);
        console.log(workorderLog);

        $scope.lastStatus = entryType;
        $scope.lastTime = new Date();

        $http.put('http://'+server+':'+port+'/workorders/log/'+Authentication.user.company+'/'+$scope.workorder._id, workorderLog).success(function(response) {
            // yay we posted a time clock entry

        });
    };


    $scope.takePicture = function() {
        var options = {
            quality : 75,
            destinationType : Camera.DestinationType.FILE_URI,
            sourceType : Camera.PictureSourceType.CAMERA,
            allowEdit : true,
            encodingType: Camera.EncodingType.JPEG,
            targetWidth: 100,
            targetHeight: 100,
            popoverOptions: CameraPopoverOptions,
            saveToPhotoAlbum: true
        };

        // todo:  Upload the picture to amazon s3
        // s3 info:
       // "accessKeyId": "AKIAIOS35YCN7MKV6L2Q",
        //    "secretAccessKey": "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",
         //   "bucket": "PMToolbelt"

        // todo: Save the picure to the webservice
        // take $scope.workorder and add the image url from s3


        // code from the web version that may help:

       /* $scope.start = function (index) {
            var file = $scope.selectedFiles[index];
            $scope.progress[index] = 0;
            S3Policy.get({mimeType: file.type}, function (response) {
                var s3Params = response;
                $scope.upload[index] = $upload.upload({
                    url: 'https://s3.amazonaws.com/' + $rootScope.config.awsConfig.bucket,
                    method: 'POST',
                    data: {
                        'key': $rootScope.config.awsConfig.bucket + '/' + Math.round(Math.random() * 10000) + '$$' + file.name,
                        'acl': 'public-read',
                        'Content-Type': file.type,
                        'AWSAccessKeyId': s3Params.AWSAccessKeyId,
                        'success_action_status': '201',
                        'Policy': s3Params.s3Policy,
                        'Signature': s3Params.s3Signature
                    },
                    file: file
                }).then(function (response) {
                    $scope.progress[index] = parseInt(100);
                    if (response.status === 201) {
                        var data = xml2json.parser(response.data),
                            parsedData;
                        parsedData = {
                            location: data.postresponse.location,
                            bucket: data.postresponse.bucket,
                            key: data.postresponse.key,
                            etag: data.postresponse.etag
                        };
                        $scope.workorder.photos.push({name: file.name, url: parsedData.location});
                    } else {
                        alert('Upload Failed');
                    }
                }, null, function (evt) {
                    $scope.progress[index] = parseInt(100.0 * evt.loaded / evt.total);
                });
            });
        };*/
        //END CODE FROM WEB VERSION

        // TO UPDATE THE WORK ORDER:
        // PUT REQUEST TO :  stage.pmtoolbelt.com/workorders/:workorderId



        $cordovaCamera.getPicture(options).then(function(imageData) {
            // Success! Image data is here
            console.log('got a pic');
            console.log(imageData);
        }, function(err) {
            // An error occured. Show a message to the user
        });
    }

});

